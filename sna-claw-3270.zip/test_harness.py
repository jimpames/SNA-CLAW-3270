#!/usr/bin/env python3
"""
SNA-CLAW-3270 Test Harness for Windows
"""

from ai_3270_claw_worker import ClawWorker

def main():
    print("=== SNA-CLAW-3270 Test Harness ===")
    try:
        worker = ClawWorker()
        print("✅ All configurations loaded successfully!")
        print(f"   Backends loaded : {len(worker.backends)}")
        print(f"   Workflows loaded: {len(worker.skills.get('workflows', {}))}")
        print(f"   Available backends: {list(worker.backends.keys())}")
        print("\n🎉 System is ready to use!")
    except Exception as e:
        print(f"❌ Error loading configurations: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()