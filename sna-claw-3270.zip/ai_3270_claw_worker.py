#!/usr/bin/env python3
"""
SNA-CLAW-3270 AI Worker - skills-based dispatch.

The hardcoded MUSIC/SP demo has been replaced by a skill-driven path:
the worker loads config/skills.ini at startup, then routes natural-language
intents by:

  1. Direct call shortcut: "skill:NAME [param=value ...]"
       e.g. "skill:music-signon userid=$000 password=music"

  2. Convenience: the legacy "logon to music..." prompt is implemented
     by composing nav-cerberus-gate + music-signon. Demonstrates how an
     LLM dispatcher would chain skills. Credentials still default to
     $000/music but can be overridden in the prompt.

  3. Anything else: show current screen preview.

The LLM dispatcher (a future addition) would take a NL intent and pick
which skills to call and in what order. The infrastructure is ready for
that; the LLM call site is the only missing piece.
"""

import configparser
import logging
import re
from pathlib import Path
from typing import Dict, List, Optional

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class ClawSession:
    def __init__(self, backend_config: Dict):
        self.backend = backend_config
        self.state = "LOGGED_OUT"
        self.connector = None
        self.connected = False

    def connect(self):
        from subsystems.tn3270_connector import TN3270Connector
        self.connector = TN3270Connector(self.backend)
        ok = self.connector.connect()
        if ok:
            self.connected = True
            self.state = "CONNECTED"
        return ok

    def send(self, mnemonic, wait_for=None, timeout=20.0):
        return self.connector.send(mnemonic, wait_for=wait_for, timeout=timeout) \
            if self.connector else None

    def pfkey(self, key, wait_for=None, timeout=20.0):
        return self.connector.pfkey(key, wait_for=wait_for, timeout=timeout) \
            if self.connector else None

    def scrhas(self, text):
        return bool(self.connector and self.connector.scrhas(text))

    def wait_for(self, text, timeout=20.0):
        return bool(self.connector and self.connector.wait_for(text, timeout))

    def is_alive(self):
        return bool(self.connector and self.connector.is_alive())

    def get_screen(self):
        return self.connector.get_screen() if self.connector else "[No session]"


class ClawWorker:
    def __init__(self, config_dir: str = "config", skills_dir: str = "skills"):
        from subsystems.skill_registry import SkillRegistry

        self.config_dir = Path(config_dir)
        self.skills_dir = Path(skills_dir)
        self.backends: Dict = {}
        self.sessions: Dict[str, ClawSession] = {}
        self.registry = SkillRegistry()

        self.load_configurations()
        self.registry.load(
            ini_path=str(self.config_dir / "skills.ini"),
            python_skills_dir=str(self.skills_dir),
        )

    def load_configurations(self):
        backends_cfg = configparser.ConfigParser()
        f = self.config_dir / "backends.ini"
        if f.exists():
            backends_cfg.read(f)
            self.backends = {
                s.split(".", 1)[1]: dict(backends_cfg[s])
                for s in backends_cfg.sections() if s.startswith("backends.")
            }
        logger.info(f"Loaded {len(self.backends)} backends")

    def _detect_backend(self, text: str) -> str:
        t = text.lower()
        if any(x in t for x in ['mvs', 'tso', 'tk5', 'turnkey']):  return 'mvs_tk5'
        if any(x in t for x in ['vm', 'sixpack', 'cms']):          return 'vm_sixpack'
        if any(x in t for x in ['music', 'msp', 'workbench']):     return 'music_sp'
        if any(x in t for x in ['zlinux', 'linux']):               return 'zlinux_390x'
        return 'music_sp'

    def get_session(self, backend_id: str) -> Optional[ClawSession]:
        if backend_id not in self.sessions and backend_id in self.backends:
            sess = ClawSession(self.backends[backend_id])
            sess.connect()
            self.sessions[backend_id] = sess
        return self.sessions.get(backend_id)

    # --------------------------------------------------------- skill helpers
    def list_skills(self) -> List[Dict]:
        return [s.to_dict() for s in self.registry.list()]

    def call_skill(self, name: str, session: ClawSession, **params):
        return self.registry.call(name, session, **params)

    def _print_skill_result(self, result):
        d = result.to_dict()
        status = "ok" if d["ok"] else "FAIL"
        print(f"  [{status}] {d['skill']}: {d['message']}")
        for s in d["steps_run"]:
            print(f"        . {s}")
        if d["error_step"]:
            print(f"        ! failed at: {d['error_step']}")

    # ------------------------------------------------------ parsing dispatch
    _SKILL_DIRECT_RE = re.compile(r"^skill:([a-zA-Z0-9_\-]+)(?:\s+(.*))?$",
                                  re.IGNORECASE)
    _KV_RE = re.compile(r"([a-zA-Z_][a-zA-Z0-9_]*)=(\S+)")
    _USERID_RE = re.compile(r"userid[=\s]+(\S+)", re.IGNORECASE)
    _PASSWORD_RE = re.compile(r"password[=\s]+(\S+)", re.IGNORECASE)

    def _parse_kv(self, text: str) -> Dict[str, str]:
        return {m.group(1): m.group(2) for m in self._KV_RE.finditer(text or "")}

    # --------------------------------------------------------- main entry
    def execute_intent(self, user_intent: str, backend_id: Optional[str] = None):
        logger.info(f"Intent received: {user_intent}")

        # --- Direct skill call: "skill:NAME k=v k=v"
        m = self._SKILL_DIRECT_RE.match(user_intent.strip())
        if m:
            skill_name = m.group(1)
            params = self._parse_kv(m.group(2) or "")
            backend = backend_id or self._infer_backend_for_skill(skill_name)
            session = self.get_session(backend)
            if not session or not session.connected:
                return {"status": "error",
                        "message": f"Failed to establish session for {backend}"}
            result = self.call_skill(skill_name, session, **params)
            self._print_skill_result(result)
            return {
                "status": "success" if result.ok else "error",
                "message": result.message,
                "result": result.to_dict(),
            }

        # --- Convenience: legacy "logon to music..." style.
        t = user_intent.lower()
        is_music_logon = ("music" in t
                          and any(w in t for w in ["logon", "log on", "login", "sign on"]))
        if is_music_logon:
            return self._compose_music_logon(user_intent)

        # --- Default: status / preview.
        backend = backend_id or self._detect_backend(user_intent)
        session = self.get_session(backend)
        if not session or not session.connected:
            return {"status": "error", "message": "Failed to establish session"}
        print("\nCurrent Screen Preview:")
        print(session.get_screen()[:500])
        print("\nAvailable skills:")
        for s in self.list_skills():
            print(f"  - {s['name']} ({s['backend']}): {s['description']}")
        return {"status": "success",
                "message": f"Connected to {backend.upper()}; "
                           f"{len(self.list_skills())} skills loaded"}

    def _infer_backend_for_skill(self, skill_name: str) -> str:
        d = self.registry.describe(skill_name)
        if d and d.get("backend"):
            return d["backend"]
        return "music_sp"

    def _compose_music_logon(self, intent: str) -> Dict:
        """Convenience composer: nav-cerberus-gate -> music-signon. Demonstrates
        skill chaining the way an LLM dispatcher would."""
        session = self.get_session("music_sp")
        if not session or not session.connected:
            return {"status": "error", "message": "Failed to establish session"}

        # Extract credentials from the prompt if present; fall back to demo defaults.
        m_u = self._USERID_RE.search(intent)
        m_p = self._PASSWORD_RE.search(intent)
        userid = m_u.group(1) if m_u else "$000"
        password = m_p.group(1) if m_p else "music"

        plan = [
            ("nav-cerberus-gate", {}),
            ("music-signon",      {"userid": userid, "password": password}),
        ]
        results = []
        for name, params in plan:
            # Skip nav step if precondition not met (e.g. menu_option=3 already advanced).
            spec = self.registry.skills.get(name)
            if spec and spec.precondition and not session.scrhas(spec.precondition):
                logger.info(f"PLAN SKIP: {name} (precondition not on current screen)")
                continue
            r = self.call_skill(name, session, **params)
            results.append(r)
            self._print_skill_result(r)
            if not r.ok:
                break

        ok = all(r.ok for r in results)
        print("\n" + "=" * 60)
        print("PLAN: " + ("SUCCESS" if ok else "FAILED"))
        for r in results:
            print(f"  {r.name}: {'ok' if r.ok else 'FAIL'} - {r.message}")
        print("=" * 60)
        print(session.get_screen()[:1000])
        print("=" * 60)
        return {
            "status": "success" if ok else "error",
            "message": "MUSIC/SP logon plan complete" if ok else "Plan halted on failure",
            "results": [r.to_dict() for r in results],
        }


if __name__ == "__main__":
    worker = ClawWorker()
    print("ClawWorker initialized successfully.")
    print(f"\nSkills available ({len(worker.list_skills())}):")
    for s in worker.list_skills():
        impl = " [python]" if s["has_python_impl"] else ""
        print(f"  - {s['name']}{impl}: {s['description']}")
