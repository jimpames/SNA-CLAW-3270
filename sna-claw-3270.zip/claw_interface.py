#!/usr/bin/env python3
"""
SNA-CLAW-3270 Natural Language Interface
"""

from ai_3270_claw_worker import ClawWorker

class ClawInterface:
    def __init__(self):
        self.worker = ClawWorker()
        print("\n" + "="*80)
        print("🚀 SNA-CLAW-3270 Natural Language Interface (Debug Mode)")
        print("You can now talk to the AI CLAW controller.")
        print("="*80)
        print("Examples:")
        print("  • list backends")
        print("  • use music_sp workbench")
        print("  • login to mvs_tk5")
        print("  • create a test file on music_sp")
        print("  • help")
        print("="*80 + "\n")

    def show_help(self):
        print("\nAvailable Commands:")
        print("  help                    - Show this help")
        print("  backends                - List all mainframes")
        print("  status                  - Show active sessions")
        print("  exit / quit             - Exit")
        print("\nYou can also type natural language intents:")
        print("  'use MUSIC/SP workbench'")
        print("  'login to TSO on mvs_tk5'")
        print("  'transfer a file to music_sp'")

    def run(self):
        while True:
            try:
                user_input = input("\n👤 You: ").strip()
                
                if user_input.lower() in ['exit', 'quit', 'q']:
                    print("👋 Shutting down SNA-CLAW-3270...")
                    break
                    
                elif user_input.lower() == 'help':
                    self.show_help()
                    continue
                    
                elif user_input.lower() == 'backends':
                    print("\nAvailable Backends:")
                    for bid, b in self.worker.backends.items():
                        print(f"  • {bid:12} → {b.get('name', 'Unnamed')}")
                    continue
                    
                elif user_input.lower() == 'status':
                    print("\nActive Sessions:", len(self.worker.sessions))
                    for bid, sess in self.worker.sessions.items():
                        print(f"  • {bid}: {sess.state}")
                    continue

                # Main path: Send intent to CLAW Worker
                print("🤖 CLAW Thinking...")
                result = self.worker.execute_intent(user_input)
                
                print("✅", result.get("message", "Command executed"))
                
            except KeyboardInterrupt:
                print("\n\nGoodbye!")
                break
            except Exception as e:
                print(f"❌ Error: {e}")

if __name__ == "__main__":
    interface = ClawInterface()
    interface.run()