#!/usr/bin/env python3
"""
Proxy3270 Shim - RENEGOTIATION PROXY MODE.

When proxy3270 hands off to a backend (Hercules MUSIC/SP), the backend
performs a fresh Telnet option negotiation that tnz handles incompletely:
it acks only the last WONT/DONT, replies "IBM-DYNAMIC" to every SEND
for terminal type, and doesn't cycle through types. Hercules drops the
session as a result.

This shim now handles the renegotiation on tnz's behalf, the same way
QWS3270/Vista3270/x3270 do. After the menu choice:
  1. We answer EVERY WONT/DONT in the un-negotiate burst (DONT/WONT respectively).
  2. We complete a full terminal-type cycle with Hercules:
        IBM-DYNAMIC → IBM-3279-2-E → IBM-3278-2-E → IBM-3278-2 → repeat last
  3. We ack DO BINARY with WILL BINARY, DO EOR with WILL EOR.
  4. We answer DO TERMINAL-TYPE with WILL TERMINAL-TYPE.
  5. Once the first 3270 data byte arrives (Erase/Write 0xF5 or similar),
     we exit renegotiation mode and pass everything through to tnz.

tnz comes online into a freshly-negotiated session and never sees any of
the renegotiation transactions, exactly like it never saw the initial
proxy3270 negotiation.
"""

import logging
import os
import socket
import threading
import time
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

TRACE = os.environ.get("SHIM_TRACE", "0") not in ("0", "", "false", "False")

# Telnet bytes
IAC, DONT, DO, WONT, WILL, SB, SE = 0xFF, 0xFE, 0xFD, 0xFC, 0xFB, 0xFA, 0xF0
# Telnet options
OPT_BINARY        = 0x00
OPT_TIMING_MARK   = 0x06
OPT_TERMINAL_TYPE = 0x18
OPT_EOR_OPT       = 0x19
OPT_TN3270E       = 0x28
# Subneg sub-commands for TERMINAL-TYPE
TT_IS, TT_SEND = 0x00, 0x01

# Terminal-type cycle - same set QWS3270 advertises. Hercules will pick the
# first one it likes. The last entry is repeated to signal end-of-list.
TERM_TYPES = [b"IBM-DYNAMIC", b"IBM-3279-2-E", b"IBM-3278-2-E", b"IBM-3278-2"]


def _cmd_name(c): return {WILL:"WILL", WONT:"WONT", DO:"DO", DONT:"DONT"}.get(c, f"0x{c:02X}")
def _opt_name(o):
    return {OPT_BINARY:"BINARY", OPT_EOR_OPT:"EOR",
            OPT_TERMINAL_TYPE:"TERMINAL-TYPE",
            OPT_TIMING_MARK:"TIMING-MARK",
            OPT_TN3270E:"TN3270E"}.get(o, f"0x{o:02X}")


def _hexdump_short(label: str, data: bytes, max_bytes: int = 64):
    if not TRACE or not data:
        return
    snippet = data[:max_bytes]
    hexed = " ".join(f"{b:02x}" for b in snippet)
    suffix = f" ...(+{len(data) - max_bytes} more)" if len(data) > max_bytes else ""
    logger.info(f"TRACE {label} [{len(data)}B]: {hexed}{suffix}")


class Proxy3270Shim:
    def __init__(self, remote_host, remote_port, bind_host="127.0.0.1"):
        self.remote_host = remote_host
        self.remote_port = remote_port
        self.bind_host = bind_host
        self.listener: Optional[socket.socket] = None
        self.local_port: Optional[int] = None
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> int:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((self.bind_host, 0))
        s.listen(1)
        s.settimeout(0.5)
        self.listener = s
        self.local_port = s.getsockname()[1]
        self._thread = threading.Thread(
            target=self._accept_loop,
            name=f"Proxy3270Shim:{self.local_port}",
            daemon=True,
        )
        self._thread.start()
        logger.info(
            f"Shim listening on {self.bind_host}:{self.local_port} "
            f"-> {self.remote_host}:{self.remote_port} "
            f"(trace={'on' if TRACE else 'off'}, mode=reneg-proxy)"
        )
        return self.local_port

    def stop(self):
        self._stop.set()
        if self.listener:
            try: self.listener.close()
            except Exception: pass

    def _accept_loop(self):
        try:
            while not self._stop.is_set():
                try:
                    csock, addr = self.listener.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break
                logger.info(f"Shim accepted from {addr}")
                threading.Thread(
                    target=self._handle, args=(csock,), daemon=True
                ).start()
        finally:
            try: self.listener.close()
            except Exception: pass

    def _handle(self, client):
        upstream = None
        try:
            upstream = socket.create_connection(
                (self.remote_host, self.remote_port), timeout=10
            )
            upstream.settimeout(None)
            try: client.settimeout(None)
            except Exception: pass
            try:
                upstream.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            except Exception: pass

            logger.info(
                f"Shim connected upstream {self.remote_host}:{self.remote_port}"
            )
            ctx = _RenegProxy(client_sock=client, upstream_sock=upstream)
            t_s2c = threading.Thread(
                target=self._pump_s2c, args=(upstream, client, ctx), daemon=True
            )
            t_c2s = threading.Thread(
                target=self._pump_c2s, args=(client, upstream), daemon=True
            )
            t_s2c.start()
            t_c2s.start()
            t_s2c.join()
            t_c2s.join()
        except Exception as e:
            logger.error(f"Shim _handle error: {e}", exc_info=True)
        finally:
            for s in (client, upstream):
                if s:
                    try: s.shutdown(socket.SHUT_RDWR)
                    except Exception: pass
                    try: s.close()
                    except Exception: pass
            logger.info("Shim connection closed")

    @staticmethod
    def _pump_c2s(src, dst):
        try:
            while True:
                data = src.recv(8192)
                if not data:
                    logger.info("Shim: c->s EOF")
                    break
                _hexdump_short("c->s", data)
                dst.sendall(data)
        except Exception as e:
            logger.info(f"Shim: c->s error: {e}")

    @staticmethod
    def _pump_s2c(src, dst, ctx):
        try:
            while True:
                data = src.recv(8192)
                if not data:
                    logger.info("Shim: s->c EOF")
                    break
                _hexdump_short("s->raw", data)
                to_client, to_server = ctx.feed(data)
                if to_server:
                    _hexdump_short("shim->s", bytes(to_server))
                    try: src.sendall(to_server)
                    except Exception: pass
                if to_client:
                    _hexdump_short("s->c (fwd)", bytes(to_client))
                    try: dst.sendall(to_client)
                    except Exception:
                        logger.info("Shim: s->c send failed")
                        break
        except Exception as e:
            logger.info(f"Shim: s->c error: {e}")


class _RenegProxy:
    """
    Server->client stream filter that proxies the renegotiation:
      - Always answers IAC commands the server sends, so the server gets a
        well-formed RFC-compliant peer for every WONT/DONT/DO/WILL.
      - Cycles through TERM_TYPES on successive TERMINAL-TYPE SEND subnegs.
      - Once any non-Telnet 3270 data byte arrives (first 0xF5 etc.) AND
        the renegotiation appears settled (last few sends were normal
        ack pairs), transitions to passthrough.

    Initially, we are in "passthrough" mode for the FIRST exchange (the
    proxy3270 menu) - tnz handles that itself fine. We switch into
    "intercept" mode the moment we see an unsolicited IAC WONT or IAC DONT
    from the server (which is the un-negotiate burst signature).
    """
    def __init__(self, client_sock, upstream_sock):
        self.client_sock = client_sock
        self.upstream_sock = upstream_sock
        self.intercepting = False
        self.term_type_index = 0
        self.partial = bytearray()
        self._mode_logged = False

    def _enter_intercept(self, trigger_cmd, trigger_opt):
        self.intercepting = True
        self.term_type_index = 0
        self._mode_logged = False
        logger.info(
            f"Shim: ENTERING INTERCEPT MODE on IAC {_cmd_name(trigger_cmd)} "
            f"{_opt_name(trigger_opt)} - will proxy renegotiation"
        )

    def _exit_intercept(self, reason: str):
        self.intercepting = False
        logger.info(f"Shim: EXIT INTERCEPT - {reason}; now passthrough to client")

    def _next_term_type(self) -> bytes:
        """Return the next terminal type in the cycle. After the last,
        repeat it (the RFC 1091 way to signal end-of-list)."""
        i = min(self.term_type_index, len(TERM_TYPES) - 1)
        self.term_type_index += 1
        return TERM_TYPES[i]

    def feed(self, data: bytes) -> Tuple[bytes, bytes]:
        if self.partial:
            data = bytes(self.partial) + data
            self.partial.clear()

        # If we're not yet intercepting, scan for the un-negotiate signature.
        if not self.intercepting:
            # Detect "IAC WONT <opt>" or "IAC DONT <opt>" anywhere in this
            # chunk as the trigger.
            i, n = 0, len(data)
            while i + 2 < n:
                if data[i] == IAC and data[i + 1] in (WONT, DONT):
                    self._enter_intercept(data[i + 1], data[i + 2])
                    break
                i += 1
            if not self.intercepting:
                # Plain passthrough.
                return data, b""

        # In intercept mode: parse and respond to Telnet commands, swallow
        # them, do NOT forward to client. Forward only non-Telnet payload.
        # On first non-Telnet 3270 data, exit intercept and pass remainder.
        out_client = bytearray()
        out_server = bytearray()
        i, n = 0, len(data)

        while i < n:
            b = data[i]

            if b != IAC:
                # Non-Telnet byte. If we're still in intercept mode, this
                # is the first 3270 stream byte (Erase/Write, Write, ...).
                # Exit intercept and pass this and the rest through.
                if not self._mode_logged:
                    self._exit_intercept(
                        f"first 3270 data byte 0x{b:02x} arrived"
                    )
                    self._mode_logged = True
                out_client.extend(data[i:])
                self.intercepting = False
                break

            if i + 1 >= n:
                self.partial.extend(data[i:])
                break
            cmd = data[i + 1]

            # IAC IAC - escaped 0xFF data byte. Forward as data.
            if cmd == IAC:
                # First data byte? Exit intercept.
                if not self._mode_logged:
                    self._exit_intercept("escaped IAC data byte")
                    self._mode_logged = True
                out_client.extend(data[i:])
                self.intercepting = False
                break

            # WILL/WONT/DO/DONT - 3 bytes, answer per RFC 854 / 1091.
            if cmd in (WILL, WONT, DO, DONT):
                if i + 2 >= n:
                    self.partial.extend(data[i:])
                    break
                opt = data[i + 2]
                self._handle_neg(cmd, opt, out_server)
                i += 3
                continue

            # IAC SB <opt> ... IAC SE
            if cmd == SB:
                end = -1; j = i + 2
                while j < n - 1:
                    if data[j] == IAC and data[j + 1] == SE:
                        end = j + 2; break
                    j += 1
                if end == -1:
                    self.partial.extend(data[i:])
                    break
                seq = data[i:end]
                self._handle_subneg(seq, out_server)
                i = end
                continue

            # Other 2-byte IAC commands - skip silently in intercept mode.
            logger.info(f"Shim: intercept skipping IAC 0x{cmd:02X}")
            i += 2

        return bytes(out_client), bytes(out_server)

    def _handle_neg(self, cmd: int, opt: int, out_server: bytearray):
        """Answer a WILL/WONT/DO/DONT in a polite, RFC-compliant way."""
        if cmd == WONT:
            reply = (IAC, DONT, opt)
        elif cmd == DONT:
            reply = (IAC, WONT, opt)
        elif cmd == DO:
            # Agree to options we want to support; refuse others.
            if opt in (OPT_BINARY, OPT_EOR_OPT, OPT_TERMINAL_TYPE):
                reply = (IAC, WILL, opt)
            else:
                reply = (IAC, WONT, opt)
        elif cmd == WILL:
            if opt in (OPT_BINARY, OPT_EOR_OPT, OPT_TIMING_MARK):
                reply = (IAC, DO, opt)
            else:
                reply = (IAC, DONT, opt)
        else:
            return

        out_server.extend(reply)
        logger.info(
            f"Shim: server IAC {_cmd_name(cmd)} {_opt_name(opt)}  ->  "
            f"reply IAC {_cmd_name(reply[1])} {_opt_name(opt)}"
        )

    def _handle_subneg(self, seq: bytes, out_server: bytearray):
        """Handle IAC SB ... IAC SE. We answer TERMINAL-TYPE SEND
        with the next type in our cycle."""
        # seq[0:2] = IAC SB ; seq[2] = opt ; seq[-2:] = IAC SE
        if len(seq) < 6:
            return
        opt = seq[2]
        if opt == OPT_TERMINAL_TYPE and seq[3] == TT_SEND:
            term = self._next_term_type()
            reply = bytes([IAC, SB, OPT_TERMINAL_TYPE, TT_IS]) + term + bytes([IAC, SE])
            out_server.extend(reply)
            logger.info(
                f"Shim: server SB TERMINAL-TYPE SEND  ->  "
                f"reply IS {term.decode('ascii')}"
            )
        else:
            # Unknown subneg in intercept mode - acknowledge minimally.
            logger.info(f"Shim: intercept ignoring SB for {_opt_name(opt)}")


if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    if len(sys.argv) != 3:
        print("usage: python proxy3270_shim.py <remote_host> <remote_port>")
        sys.exit(1)
    shim = Proxy3270Shim(sys.argv[1], int(sys.argv[2]))
    port = shim.start()
    print(f"Shim running on 127.0.0.1:{port}")
    try: threading.Event().wait()
    except KeyboardInterrupt: shim.stop()
