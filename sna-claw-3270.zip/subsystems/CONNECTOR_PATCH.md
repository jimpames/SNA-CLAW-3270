# One small patch to tn3270_connector.py

Open `subsystems/tn3270_connector.py` in your editor and find this block
in the `connect()` method (around line 110-120):

```python
            if self.menu_option and self.ati.scrhas("CERBERUS GATE"):
                logger.info(f"CERBERUS GATE detected; sending [tab]{self.menu_option}[enter]")
                self._wait_unlock(timeout=10.0)
                self.ati.send(f"[tab]{self.menu_option}[enter]")
                self._wait_for("not CERBERUS GATE",
                               lambda: not self.ati.scrhas("CERBERUS GATE"),
                               timeout=20.0)
                self._screen_peek(f"after menu_option={self.menu_option}")
            else:
                logger.info("No CERBERUS GATE on initial screen; nothing to advance")
```

Replace the `_wait_for("not CERBERUS GATE", ...)` line and the peek with
this slightly longer settle sequence:

```python
            if self.menu_option and self.ati.scrhas("CERBERUS GATE"):
                logger.info(f"CERBERUS GATE detected; sending [tab]{self.menu_option}[enter]")
                self._wait_unlock(timeout=10.0)
                self.ati.send(f"[tab]{self.menu_option}[enter]")
                # First wait: CERBERUS goes away (proxy3270 closed the menu).
                self._wait_for("not CERBERUS GATE",
                               lambda: not self.ati.scrhas("CERBERUS GATE"),
                               timeout=20.0)
                # Second wait: the backend's first screen actually paints.
                # The renegotiation handoff takes ~100-200ms, then Hercules
                # sends its initial screen. Without this second wait we
                # declare "Connected" against a blank buffer.
                self._wait_for("backend screen populated",
                               lambda: self._has_content(),
                               timeout=10.0)
                self._screen_peek(f"after menu_option={self.menu_option}")
            else:
                logger.info("No CERBERUS GATE on initial screen; nothing to advance")
```

That's it. One added `_wait_for` call so we don't declare connect complete
on a blank screen.

## Why this matters for skills

Without this, the first skill call after `list backends` sees an empty
screen buffer and fails precondition checks even though the backend
*did* paint a screen 100-200ms after we declared "Connected." The new
skill registry already does a brief `wait_for` on preconditions to
compensate, but it's cleaner to have the connector deliver a populated
screen in the first place.
