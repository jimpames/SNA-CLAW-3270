#!/usr/bin/env python3
"""
Skill registry and runner for SNA-CLAW-3270.

Loads config/skills.ini and (optionally) Python implementations from
skills/<name>.py, then offers:

    registry = SkillRegistry()
    registry.load("config/skills.ini", python_skills_dir="skills")

    registry.list()          -> [SkillSpec, ...]
    registry.describe(name)  -> dict (for LLM/CLI display)
    registry.call(name, session, **params) -> SkillResult

Failure modes are explicit. Preconditions are GATES: if the current
screen doesn't satisfy them, the skill refuses to run with a clear
error. Postconditions are GATES too: after all steps execute, we
verify the postcondition or report failure.
"""

import configparser
import importlib.util
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------- result
@dataclass
class SkillResult:
    name: str
    ok: bool
    message: str = ""
    steps_run: List[str] = field(default_factory=list)
    error_step: Optional[str] = None
    final_screen: str = ""

    def to_dict(self):
        return {
            "skill": self.name,
            "ok": self.ok,
            "message": self.message,
            "steps_run": list(self.steps_run),
            "error_step": self.error_step,
        }


# -------------------------------------------------------------- spec
@dataclass
class SkillSpec:
    name: str
    description: str
    backend: str
    params: List[str] = field(default_factory=list)
    param_defaults: Dict[str, str] = field(default_factory=dict)
    precondition: Optional[str] = None
    postcondition: Optional[str] = None
    timeout: float = 20.0
    steps: List[str] = field(default_factory=list)
    python_impl: Optional[Callable] = None  # if not None, called instead of DSL

    def required_params(self) -> List[str]:
        return [p for p in self.params if p not in self.param_defaults]

    def to_dict(self):
        return {
            "name": self.name,
            "description": self.description,
            "backend": self.backend,
            "params": self.params,
            "param_defaults": dict(self.param_defaults),
            "precondition": self.precondition,
            "postcondition": self.postcondition,
            "has_python_impl": self.python_impl is not None,
        }


# ----------------------------------------------------------- parsing
_PARAM_RE = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}")

def _parse_params_decl(decl: str):
    """'userid, password, opt=3' -> (['userid','password','opt'], {'opt':'3'})"""
    names: List[str] = []
    defaults: Dict[str, str] = {}
    if not decl.strip():
        return names, defaults
    for raw in decl.split(","):
        part = raw.strip()
        if not part:
            continue
        if "=" in part:
            name, default = part.split("=", 1)
            names.append(name.strip())
            defaults[name.strip()] = default.strip()
        else:
            names.append(part)
    return names, defaults


def _parse_steps_block(block: str) -> List[str]:
    lines: List[str] = []
    for raw in block.splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        lines.append(stripped)
    return lines


# ----------------------------------------------------------- registry
class SkillRegistry:
    def __init__(self):
        self.skills: Dict[str, SkillSpec] = {}

    def load(self, ini_path: str, python_skills_dir: Optional[str] = None):
        cfg = configparser.ConfigParser()
        # Preserve case for INI keys (we don't need it, but tidy).
        cfg.optionxform = str
        path = Path(ini_path)
        if not path.exists():
            logger.warning(f"Skill INI not found at {ini_path}; no skills loaded")
            return
        cfg.read(path)
        for section in cfg.sections():
            if not section.startswith("skill."):
                continue
            name = section.split(".", 1)[1]
            s = cfg[section]
            params, defaults = _parse_params_decl(s.get("params", ""))
            spec = SkillSpec(
                name=name,
                description=s.get("description", "").strip(),
                backend=s.get("backend", "").strip(),
                params=params,
                param_defaults=defaults,
                precondition=(s.get("precondition") or "").strip() or None,
                postcondition=(s.get("postcondition") or "").strip() or None,
                timeout=float(s.get("timeout", "20")),
                steps=_parse_steps_block(s.get("steps", "")),
            )
            self.skills[name] = spec

        if python_skills_dir:
            self._load_python_impls(python_skills_dir)

        logger.info(f"SkillRegistry: loaded {len(self.skills)} skill(s)")
        for spec in self.skills.values():
            impl = "py" if spec.python_impl else "dsl"
            logger.info(f"  - {spec.name} [{impl}] ({spec.backend}): {spec.description}")

    def _load_python_impls(self, dir_path: str):
        d = Path(dir_path)
        if not d.exists():
            return
        for name, spec in list(self.skills.items()):
            # File name uses the skill name with hyphens turned into underscores.
            mod_filename = name.replace("-", "_") + ".py"
            mod_path = d / mod_filename
            if not mod_path.exists():
                continue
            try:
                module = self._load_module_from_path(name, mod_path)
                impl = getattr(module, "run", None)
                if callable(impl):
                    spec.python_impl = impl
                    logger.info(f"  (loaded python impl for {name})")
                else:
                    logger.warning(
                        f"{mod_path} has no callable run(); ignoring"
                    )
            except Exception as e:
                logger.error(f"failed to load python impl for {name}: {e}",
                             exc_info=True)

    @staticmethod
    def _load_module_from_path(name, path):
        spec = importlib.util.spec_from_file_location(
            f"sna_claw_skill_{name.replace('-', '_')}", str(path)
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def list(self) -> List[SkillSpec]:
        return list(self.skills.values())

    def describe(self, name: str) -> Optional[dict]:
        s = self.skills.get(name)
        return s.to_dict() if s else None

    # ------------------------------------------------------------- call
    def call(self, name: str, session, **params) -> SkillResult:
        spec = self.skills.get(name)
        if spec is None:
            return SkillResult(name=name, ok=False,
                               message=f"unknown skill: {name}")

        # Validate parameters.
        missing = [p for p in spec.required_params() if p not in params]
        if missing:
            return SkillResult(
                name=name, ok=False,
                message=f"missing required params: {missing}",
            )
        # Fill defaults.
        resolved = {}
        for p in spec.params:
            if p in params:
                resolved[p] = str(params[p])
            elif p in spec.param_defaults:
                resolved[p] = spec.param_defaults[p]

        # Session liveness.
        if not session or not session.is_alive():
            return SkillResult(
                name=name, ok=False,
                message="session not alive",
            )

        # Precondition gate. Peek the actual screen so a failure tells us
        # what we were looking at, not just "didn't see X."
        if spec.precondition:
            # Give the screen a brief chance to settle - if MUSIC/SP just
            # painted a screen, the buffer may need one tnz wait cycle.
            settled = session.wait_for(spec.precondition, timeout=3.0)
            try:
                session.connector._screen_peek(f"precondition[{name}]")
            except Exception:
                pass
            if not settled:
                screen = session.get_screen()
                return SkillResult(
                    name=name, ok=False,
                    message=(f"precondition not met: screen does not contain "
                             f"{spec.precondition!r}"),
                    final_screen=screen[:400],
                )

        logger.info(f"SKILL CALL: {name} params={resolved}")

        # Dispatch to Python impl if present, else interpret DSL.
        if spec.python_impl is not None:
            try:
                py_result = spec.python_impl(session, **resolved)
            except Exception as e:
                logger.error(f"skill {name} python impl raised: {e}", exc_info=True)
                return SkillResult(
                    name=name, ok=False,
                    message=f"python impl raised: {e}",
                    final_screen=session.get_screen()[:200],
                )
            # Normalize the return: accept SkillResult, dict, bool, or None.
            result = _normalize_py_result(name, py_result)
        else:
            result = self._run_dsl(spec, session, resolved)

        # Postcondition gate (only if all steps succeeded so far).
        if result.ok and spec.postcondition:
            if not session.scrhas(spec.postcondition):
                result.ok = False
                result.message = (f"postcondition not met: screen does not "
                                  f"contain {spec.postcondition!r}")

        if not result.final_screen:
            try:
                result.final_screen = session.get_screen()[:400]
            except Exception:
                pass

        if result.ok:
            logger.info(f"SKILL OK: {name}")
        else:
            logger.warning(f"SKILL FAIL: {name} -> {result.message}")
        return result

    # --------------------------------------------------------- DSL interp
    def _run_dsl(self, spec: SkillSpec, session, params: Dict[str, str]) -> SkillResult:
        result = SkillResult(name=spec.name, ok=True)

        def sub(text: str) -> str:
            # Replace {param_name} with the resolved value. Unknown names
            # raise a clear error rather than passing through.
            def replace(m):
                k = m.group(1)
                if k not in params:
                    raise KeyError(
                        f"step references unknown param {{{k}}}; "
                        f"available: {list(params)}"
                    )
                return params[k]
            return _PARAM_RE.sub(replace, text)

        for step in spec.steps:
            try:
                action, _, arg = step.partition(":")
                action = action.strip().lower()
                arg = arg.strip()
                arg = sub(arg)
            except KeyError as e:
                result.ok = False
                result.error_step = step
                result.message = str(e)
                return result

            result.steps_run.append(step)

            if action == "send":
                ret = session.send(arg)
                if _is_error(ret):
                    result.ok = False
                    result.error_step = step
                    result.message = f"send failed: {ret}"
                    return result
            elif action == "type":
                ret = session.connector.type_text(arg)
                if _is_error(ret):
                    result.ok = False
                    result.error_step = step
                    result.message = f"type failed: {ret}"
                    return result
            elif action == "wait":
                if not session.wait_for(arg, timeout=spec.timeout):
                    result.ok = False
                    result.error_step = step
                    result.message = f"wait timed out for {arg!r}"
                    return result
            elif action == "fail_if":
                if session.scrhas(arg):
                    result.ok = False
                    result.error_step = step
                    result.message = f"fail_if matched: screen contains {arg!r}"
                    return result
            elif action == "peek":
                try:
                    session.connector._screen_peek(f"{spec.name}:{arg}")
                except Exception:
                    pass
            else:
                result.ok = False
                result.error_step = step
                result.message = f"unknown DSL action: {action!r}"
                return result

        return result


def _is_error(s) -> bool:
    return isinstance(s, str) and s.startswith("[") and "error" in s.lower() \
        or isinstance(s, str) and s.startswith("[") and (
            "lost" in s.lower() or "timeout" in s.lower()
            or "not connected" in s.lower() or "never unlocked" in s.lower()
        )


def _normalize_py_result(name: str, raw) -> SkillResult:
    if isinstance(raw, SkillResult):
        return raw
    if isinstance(raw, dict):
        return SkillResult(
            name=name,
            ok=bool(raw.get("ok", True)),
            message=str(raw.get("message", "")),
            steps_run=list(raw.get("steps_run", [])),
            error_step=raw.get("error_step"),
            final_screen=str(raw.get("final_screen", "")),
        )
    if isinstance(raw, bool):
        return SkillResult(name=name, ok=raw,
                           message="" if raw else "python impl returned False")
    if raw is None:
        return SkillResult(name=name, ok=True)
    return SkillResult(name=name, ok=False,
                       message=f"python impl returned unexpected type: {type(raw).__name__}")
