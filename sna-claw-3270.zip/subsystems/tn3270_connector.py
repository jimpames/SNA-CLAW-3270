#!/usr/bin/env python3
"""
TN3270 Connector - waits for actual screen content before declaring connected.

Changes from previous build:
  - After keyboard unlock, wait until the screen is non-empty before
    declaring success. Brand-new ATI sessions briefly show keylock=0
    before any data has arrived, leading us to peek a blank buffer and
    miss CERBERUS GATE.
  - _screen_peek now logs ALL non-blank lines (up to 24), not just first 6,
    so we can see which screen we're actually on after each step.
"""

import logging
import threading
import time
from typing import Dict, Optional

logger = logging.getLogger(__name__)

try:
    from tnz.ati import Ati
    TNZ_AVAILABLE = True
except ImportError:
    TNZ_AVAILABLE = False
    logger.warning("tnz.ati not installed - STUB mode.")


def _as_bool(v, default=False):
    if isinstance(v, bool): return v
    if v is None: return default
    return str(v).strip().lower() in ("true", "1", "yes", "y", "on")


_session_counter = 0
_session_lock = threading.Lock()
def _next_session_name(prefix: str) -> str:
    global _session_counter
    with _session_lock:
        _session_counter += 1
    safe = "".join(c if c.isalnum() else "_" for c in prefix.upper())
    return f"{safe}{_session_counter:03d}"


ERR_PREFIXES = ("[Session lost", "[Wait-for timeout", "[Keyboard never",
                "[Send error", "[Type error", "[Not connected",
                "[Bad PF key", "[No active session", "[Screen capture failed")

def is_error(result: str) -> bool:
    return isinstance(result, str) and result.startswith(ERR_PREFIXES)


class TN3270Connector:
    def __init__(self, backend_config: Dict, dump_state: bool = True):
        self.config = backend_config
        self.ati: Optional["Ati"] = None
        self.session_name: Optional[str] = None
        self.connected = False
        self.dump_state = dump_state
        self.shim = None
        self.menu_option = backend_config.get("menu_option")

    def is_alive(self) -> bool:
        if not (self.ati and self.connected):
            return False
        try:
            return self.ati.get_tnz() is not None
        except Exception:
            return False

    # ------------------------------------------------------------------ #
    def connect(self) -> bool:
        if not TNZ_AVAILABLE:
            logger.info("STUB MODE - no real TN3270 session")
            self.connected = True
            return True

        try:
            host = self.config.get("host", "tso.tso3270.com")
            port = int(self.config.get("port", 26640))
            secure = _as_bool(self.config.get("secure"), default=False)
            use_shim = _as_bool(self.config.get("use_proxy3270_shim"), default=True)
            backend_id = self.config.get("name") or "BACKEND"
            self.session_name = _next_session_name(backend_id)

            if use_shim:
                from subsystems.proxy3270_shim import Proxy3270Shim
                self.shim = Proxy3270Shim(host, port)
                shim_port = self.shim.start()
                connect_host, connect_port = "127.0.0.1", shim_port
                logger.info(
                    f"Connecting via proxy3270 shim "
                    f"127.0.0.1:{shim_port} -> {host}:{port}"
                )
            else:
                connect_host, connect_port = host, port
                logger.info(f"Connecting directly to {host}:{port}")

            self.ati = Ati()
            if not secure:
                self.ati.set("SESSION_SSL", "0")
                logger.info("SESSION_SSL=0 (plaintext TN3270)")
            self.ati.set("KEYUNLOCK", "120")
            self.ati.set("MAXLOSTWARN", "0")
            self.ati.set("SESSION_HOST", connect_host)
            self.ati.set("SESSION_PORT", str(connect_port))

            logger.info(f"ATI: set SESSION='{self.session_name}'")
            self.ati.set("SESSION", self.session_name)
            rc = self.ati.rc
            if rc not in (0, 1):
                logger.error(f"SESSION set rc={rc}")
                return False

            # Wait for the initial screen to actually have content,
            # not just for keylock to be 0. (A brand-new session reports
            # keylock=0 before any host bytes have arrived.)
            if not self._wait_for_screen(timeout=30.0):
                logger.error("No screen content arrived within 30s.")
                return False

            self._screen_peek("after initial connect")

            # First send needs is_alive() to pass; flip the flag here.
            self.connected = True

            if self.menu_option and self.ati.scrhas("CERBERUS GATE"):
                logger.info(f"CERBERUS GATE detected; sending [tab]{self.menu_option}[enter]")
                self._wait_unlock(timeout=10.0)
                self.ati.send(f"[tab]{self.menu_option}[enter]")
                self._wait_for("not CERBERUS GATE",
                               lambda: not self.ati.scrhas("CERBERUS GATE"),
                               timeout=20.0)
                self._screen_peek(f"after menu_option={self.menu_option}")
            else:
                logger.info("No CERBERUS GATE on initial screen; nothing to advance")

            logger.info(f"Connected ({self.session_name})")
            return True

        except Exception as e:
            logger.error(f"Connect failed: {e}", exc_info=True)
            self.connected = False
            return False

    def close(self):
        if self.ati and self.session_name:
            try:
                self.ati.set("SESSION", self.session_name)
                self.ati.drop("SESSION")
            except Exception:
                pass
        self.ati = None
        self.connected = False
        if self.shim:
            try: self.shim.stop()
            except Exception: pass
            self.shim = None

    # ------------------------------------------------------------------ #
    def send(self, mnemonic_string: str, wait_for: Optional[str] = None,
             timeout: float = 20.0) -> str:
        if not self.is_alive():
            logger.warning(f"send({mnemonic_string!r}) skipped: session not alive")
            return "[Session lost]"
        if not self._wait_unlock(timeout=timeout):
            logger.warning(f"send({mnemonic_string!r}): keyboard never unlocked")
            return "[Keyboard never unlocked]"
        try:
            self._state_dump(f"before send({mnemonic_string!r})")
            self.ati.send(mnemonic_string)
            if wait_for:
                ok = self._wait_for(
                    wait_for,
                    lambda: self.is_alive() and self.ati.scrhas(wait_for),
                    timeout=timeout,
                )
                if not ok:
                    return "[Wait-for timeout]"
            else:
                if not self._wait_unlock(timeout=timeout):
                    return "[Keyboard never unlocked]"
            self._screen_peek(f"after send({mnemonic_string!r})")
            return self.get_screen()
        except Exception as e:
            logger.error(f"send({mnemonic_string!r}) failed: {e}", exc_info=True)
            return f"[Send error: {e}]"

    def type_text(self, text: str) -> str:
        if not self.is_alive(): return "[Session lost]"
        try:
            self.ati.send(text)
            return self.get_screen()
        except Exception as e:
            logger.error(f"type_text({text!r}) failed: {e}", exc_info=True)
            return f"[Type error: {e}]"

    def tab(self) -> str:
        return self.send("[tab]")

    def pfkey(self, key: int, wait_for: Optional[str] = None,
              timeout: float = 20.0) -> str:
        if key == 0:
            return self.send("[enter]", wait_for=wait_for, timeout=timeout)
        if 1 <= key <= 24:
            return self.send(f"[pf{key}]", wait_for=wait_for, timeout=timeout)
        return "[Bad PF key]"

    # ------------------------------------------------------------------ #
    def get_screen(self) -> str:
        if not self.is_alive(): return "[Session lost]"
        try:
            tns = self.ati.get_tnz()
            return tns.scrstr(0, tns.buffer_size, rstrip=True)
        except Exception as e:
            logger.error(f"get_screen failed: {e}", exc_info=True)
            return "[Screen capture failed]"

    def scrhas(self, text: str) -> bool:
        if not self.is_alive(): return False
        try:
            return bool(self.ati.scrhas(text))
        except Exception:
            return False

    def wait_for(self, text: str, timeout: float = 20.0) -> bool:
        return self._wait_for(
            text,
            lambda: self.is_alive() and self.ati.scrhas(text),
            timeout,
        )

    # ------------------------------------------------------------------ #
    def _has_content(self) -> bool:
        """True if the screen buffer has any non-whitespace content."""
        if not self.ati:
            return False
        try:
            tns = self.ati.get_tnz()
            if tns is None:
                return False
            text = tns.scrstr(0, tns.buffer_size, rstrip=True)
            return bool(text and text.strip())
        except Exception:
            return False

    def _wait_for_screen(self, timeout: float = 20.0) -> bool:
        """Wait for keyboard unlock AND non-blank screen content."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.ati and self.ati.keylock == "0" and self._has_content():
                return True
            try:
                self.ati.set("MAXWAIT", "2")
                self.ati.wait(lambda: (self.ati.keylock == "0"
                                       and self._has_content()))
                return True
            except Exception:
                continue
        return (self.ati is not None and self.ati.keylock == "0"
                and self._has_content())

    def _wait_unlock(self, timeout: float = 20.0) -> bool:
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.ati and self.ati.keylock == "0":
                return True
            try:
                self.ati.set("MAXWAIT", "2")
                self.ati.wait(lambda: self.ati.keylock == "0")
                return True
            except Exception:
                if self.connected and self.ati and self.ati.get_tnz() is None:
                    logger.warning("_wait_unlock: session lost during wait")
                    return False
                continue
        return self.ati is not None and self.ati.keylock == "0"

    def _wait_for(self, label: str, predicate, timeout: float = 20.0) -> bool:
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                if predicate(): return True
            except Exception:
                pass
            try:
                self.ati.set("MAXWAIT", "2")
                self.ati.wait(predicate)
                return True
            except Exception:
                if self.connected and self.ati and self.ati.get_tnz() is None:
                    logger.warning(f"_wait_for({label!r}): session lost")
                    return False
                continue
        logger.warning(f"_wait_for({label!r}) timed out after {timeout}s")
        return False

    # ------------------------------------------------------------------ #
    def _state_dump(self, label: str = ""):
        if not (self.dump_state and self.ati): return
        try:
            tns = self.ati.get_tnz()
            attrs = {
                "keylock": self.ati.keylock,
                "seslost": self.ati.seslost,
                "rc": self.ati.rc,
                "currow": self.ati.currow,
                "curcol": self.ati.curcol,
                "tnz": "yes" if tns else "no",
            }
            if tns is not None:
                attrs["pwait"] = getattr(tns, "pwait", "?")
                attrs["slock"] = getattr(tns, "system_lock_wait", "?")
            logger.info(f"STATE [{label}] {attrs}")
        except Exception as e:
            logger.debug(f"state_dump error: {e}")

    def _screen_peek(self, label: str = "screen"):
        """Log ALL non-blank lines of the screen (up to 24) so we can see
        exactly which screen we're on. Previously truncated to 6 lines."""
        if not self.ati: return
        try:
            tns = self.ati.get_tnz()
            if tns is None:
                logger.info(f"[{label}] no Tnz (session lost)")
                return
            text = tns.scrstr(0, tns.buffer_size, rstrip=True)
            lines = [ln for ln in text.splitlines() if ln.strip()][:24]
            if not lines:
                logger.info(f"[{label}] screen blank")
                return
            logger.info(f"[{label}] non-blank screen content:")
            for ln in lines:
                logger.info(f"    | {ln[:78]}")
            logger.info(f"[{label}] ({len(lines)} non-blank lines)")
        except Exception as e:
            logger.debug(f"screen_peek error: {e}")
