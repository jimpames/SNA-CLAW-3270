# SNA-CLAW-3270 Skills System

## What got added

```
config/
  skills.ini                  # the skill catalog
skills/
  music_signon.py             # optional Python implementations
subsystems/
  skill_registry.py           # loader + DSL runner + dispatcher
ai_3270_claw_worker.py        # replaced hardcoded demo with skill dispatch
```

`tn3270_connector.py` and `proxy3270_shim.py` are unchanged.

## Drop locations

- `config/skills.ini` → `<project>/config/skills.ini`
- `skills/music_signon.py` → `<project>/skills/music_signon.py` (create the dir)
- `subsystems/skill_registry.py` → `<project>/subsystems/skill_registry.py`
- `ai_3270_claw_worker.py` → `<project>/ai_3270_claw_worker.py` (replace)

## How skills work

Each skill is one declarative section in `skills.ini`:

```ini
[skill.nav-cerberus-gate]
description    = From CERBERUS GATE, select MUSIC/SP
backend        = music_sp
precondition   = CERBERUS GATE
steps          =
    send:[tab]3[enter]
    wait:Multi-User System
postcondition  = Multi-User System
```

The runner enforces three gates:
1. **Precondition** - if the current screen doesn't contain the
   precondition text, the skill refuses to run.
2. **Per-step success** - any `send`/`wait`/`fail_if` that fails halts
   the skill with a clear error.
3. **Postcondition** - after all steps, the screen must contain the
   postcondition text; otherwise the skill reports failure.

This is the "no traffic ticket" guarantee: skills can't fire blindly out
of context, and they can't claim success without proving they reached
the expected state.

## DSL actions

```
send:<mnemonic_string>      type via tnz mnemonic-string, then wait for unlock
type:<text>                 type text without Enter
wait:<text>                 wait for the screen to contain text
fail_if:<text>              fail immediately if the screen contains text
peek:<label>                log a screen snapshot (debugging)
```

Inside any of those, `{param_name}` is replaced with the resolved parameter.

## Parameters

Declared comma-separated. Required by default; add `=default` for defaults:

```ini
params = userid, password, opt=3
```

## Python override

If `skills/<name_with_underscores>.py` exists and defines a `run(session, **params)`
function, the registry calls it instead of running the INI steps. Use this when
a skill needs branching, retries, parameter coercion, or any logic beyond
"send-wait-send-wait." See `skills/music_signon.py` for the pattern.

`run()` can return a `SkillResult`, a `dict({"ok": bool, "message": str, ...})`,
a bool, or `None` (treated as success). The registry normalizes whichever shape
you return.

## Calling skills

Two ways for now (no LLM dispatcher yet):

**Direct:**
```
skill:music-signon userid=$000 password=music
```

**Convenience composer (the legacy "logon to music..." prompt):**
```
logon to music/sp as userid $000 password music
```
This composes `nav-cerberus-gate` + `music-signon`. Demonstrates how an LLM
dispatcher will eventually chain skills. Credentials are parsed from the
prompt; falls back to `$000` / `music` if not present.

## Adding a new skill

1. Add a section to `config/skills.ini`.
2. If it needs logic, drop a `skills/<name>.py` with a `run()` function.
3. That's it. No code changes anywhere else.

## Next step: LLM dispatcher

The registry exposes `list()` and `describe(name)` which already produce
LLM-friendly metadata. The dispatcher would:

1. Receive a natural-language intent.
2. Send (intent + skill catalog) to an LLM.
3. Let the LLM decide which skills to call and with which parameters.
4. Execute each chosen skill, feed back results / screens, loop until done.

The skill layer is now ready for that. Nothing else has to change.
