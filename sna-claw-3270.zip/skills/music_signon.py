"""
Optional Python implementation for skill 'music-signon'.

The DSL version in skills.ini works fine, but this Python version
demonstrates the override pattern - useful when a skill needs:
  - branching ("if screen says X, do Y else Z")
  - retries
  - parameter normalization or validation
  - richer logging
The registry prefers this implementation over the DSL when both exist.

To remove this override and use the INI version only, delete this file.
"""

import logging
logger = logging.getLogger(__name__)


def run(session, userid: str, password: str):
    """Sign on to MUSIC/SP from its banner screen.

    Returns a dict consumed by the SkillRegistry. 'ok' is required.
    """
    # Dismiss the banner (it may print one or more 'Press ENTER' pages).
    if session.scrhas("Press the ENTER key"):
        ret = session.send("[enter]")
        if isinstance(ret, str) and ret.startswith("[") and "error" in ret.lower():
            return {"ok": False, "message": f"banner dismiss failed: {ret}"}

    if not session.wait_for("MUSIC Userid:", timeout=15.0):
        return {"ok": False, "message": "sign-on prompt did not appear"}

    ret = session.send(f"{userid}[tab]{password}[enter]")
    if isinstance(ret, str) and ret.startswith("[") and "error" in ret.lower():
        return {"ok": False, "message": f"credential submit failed: {ret}"}

    # Check explicitly for credential failure before claiming success.
    if session.scrhas("not authorized") or session.scrhas("invalid"):
        return {"ok": False, "message": "credentials rejected by MUSIC/SP"}

    if not session.wait_for("Press ENTER to continue", timeout=15.0):
        return {"ok": False, "message": "continue page did not appear"}

    ret = session.send("[enter]")
    if isinstance(ret, str) and ret.startswith("[") and "error" in ret.lower():
        return {"ok": False, "message": f"continue dismiss failed: {ret}"}

    if not session.wait_for("SELECT OPTION", timeout=15.0):
        return {"ok": False, "message": "ADMIN menu did not appear"}

    return {"ok": True, "message": f"signed on as {userid}"}
