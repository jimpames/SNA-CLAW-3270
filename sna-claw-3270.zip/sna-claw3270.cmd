@echo off
REM =============================================
REM SNA-CLAW-3270 Windows Launcher
REM Clean version for Windows 11 + venv
REM =============================================

setlocal

REM Go to script directory
cd /d "%~dp0"

REM Activate venv if it exists
if exist venv\Scripts\activate.bat (
    call venv\Scripts\activate.bat
)

if /i "%1"=="test" (
    echo === Running SNA-CLAW-3270 Test Harness ===
    python test_harness.py
) else if /i "%1"=="start" (
    echo Starting SNA-CLAW-3270 Natural Language Interface...
    python claw_interface.py
) else (
    echo Usage: %0 [test^|start]
    echo   test   - Validate INI files and configuration
    echo   start  - Launch natural language interface
    echo.
    echo Examples:
    echo   sna-claw3270.cmd test
    echo   sna-claw3270.cmd start
)

endlocal