# HALL-OF-MIRRORS-TEST-HARNESS.py
# Six Million Dollar + Hall of Mirrors Ultra-Isolated Test Suite
# Protects CI/CD from any bad recorder code

import unittest
import tempfile
import os
import shutil
from pathlib import Path
from datetime import datetime

# Import Hitsville components
from hitsville_recorder import HitsvilleRecorder
from hitsville_utils import suggest_step_name, print_screen_preview
from hitsville_cli import handle_recorder_command


class HallOfMirrorsTestHarness(unittest.TestCase):
    """Bulletproof test harness for Hitsville USA Recording Studio"""

    def setUp(self):
        """Create isolated temporary environment"""
        self.test_dir = Path(tempfile.mkdtemp(prefix="hitsville_mirrors_"))
        os.chdir(self.test_dir)
        self.recorder = HitsvilleRecorder("TestSkill_Mirrors", screenshot_mode=False)
        print(f"🪞 Test environment initialized: {self.test_dir}")

    def tearDown(self):
        """Cleanup after each test"""
        try:
            shutil.rmtree(self.test_dir, ignore_errors=True)
        except:
            pass

    def test_screen_aliasing(self):
        """Test intelligent screen detection and aliasing"""
        sample_screen = "CERBERUS GATE\nSelect service to connect to:\n1 MVS 3.8j TK5"
        self.recorder.on_screen_change(sample_screen)
        self.assertGreater(len(self.recorder.screen_aliases), 0)
        print("✅ Screen aliasing test passed")

    def test_field_level_recording(self):
        """Test field/action level recording"""
        self.recorder.on_field_action("USERID", "$000")
        self.recorder.on_field_action("PASSWORD", "music")
        self.assertEqual(len(self.recorder.steps), 2)
        print("✅ Field recording test passed")

    def test_aid_key_support(self):
        """Test PA, PF, ATTN, CLEAR, ENTER support"""
        self.recorder.on_aid_key("ENTER")
        self.recorder.on_aid_key("PF3")
        self.recorder.on_aid_key("PA1")
        self.recorder.on_aid_key("ATTN")
        self.assertEqual(len(self.recorder.steps), 4)
        print("✅ PA/PF/ATTN key support test passed")

    def test_step_naming(self