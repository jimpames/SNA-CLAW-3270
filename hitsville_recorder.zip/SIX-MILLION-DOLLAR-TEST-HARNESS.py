# SIX-MILLION-DOLLAR-TEST-HARNESS.py
# Ultimate Bulletproof Test Suite for Hitsville USA Recording Studio
# "We can rebuild it. We have the technology."

import unittest
import tempfile
import os
import shutil
import time
from pathlib import Path
from datetime import datetime

# Import Hitsville components
from hitsville_recorder import HitsvilleRecorder
from hitsville_utils import suggest_step_name, print_screen_preview
from hitsville_cli import handle_recorder_command, start_recording_session


class SixMillionDollarTestHarness(unittest.TestCase):
    """Six Million Dollar Man + Hall of Mirrors - Production Grade Test Suite"""

    def setUp(self):
        """Ultra-isolated test environment"""
        self.start_time = time.time()
        self.test_dir = Path(tempfile.mkdtemp(prefix="six_million_dollar_"))
        os.chdir(self.test_dir)
        self.recorder = HitsvilleRecorder("SixMillionTestSkill", screenshot_mode=False)
        print(f"🦸 Test environment ready: {self.test_dir.name}")

    def tearDown(self):
        """Clean up after test"""
        try:
            shutil.rmtree(self.test_dir, ignore_errors=True)
        except Exception as e:
            print(f"Warning: Cleanup issue - {e}")

    def test_01_screen_aliasing(self):
        """Test new screen detection and aliasing"""
        screen = "CERBERUS GATE\nSelect service:\n1 MVS TK5\n3 MUSIC/SP"
        self.recorder.on_screen_change(screen)
        self.assertGreater(len(self.recorder.screen_aliases), 0)
        print("✅ 01 - Screen Aliasing: PASSED")

    def test_02_field_level_recording(self):
        """Test precise field/action recording"""
        self.recorder.on_field_action("USERID", "$000")
        self.recorder.on_field_action("PASSWORD", "music")
        self.assertEqual(len(self.recorder.steps), 2)
        print("✅ 02 - Field Level Recording: PASSED")

    def test_03_full_aid_key_support(self):
        """Test all critical 3270 AID keys"""
        keys = ["ENTER", "PF3", "PF12", "PA1", "PA2", "ATTN", "CLEAR"]
        for key in keys:
            self.recorder.on_aid_key(key)
        self.assertEqual(len(self.recorder.steps), 7)
        print("✅ 03 - PA/PF/ATTN/CLEAR Support: PASSED")

    def test_04_step_management(self):
        """Test step naming and auto-suggestion"""
        self.recorder.set_step_name("SignOn_MUSIC_SP")
        self.assertEqual(self.recorder.current_step, "SignOn_MUSIC_SP")
        
        auto_name = suggest_step_name("ADMIN MAIN MENU - SELECT OPTION")
        self.assertIn("MENU", auto_name)
        print("✅ 04 - Step Management: PASSED")

    def test_05_pause_resume(self):
        """Test pause/resume during long sessions"""
        self.recorder.pause()
        self.assertTrue(self.recorder.is_paused)
        self.recorder.resume()
        self.assertFalse(self.recorder.is_paused)
        print("✅ 05 - Pause/Resume: PASSED")

    def test_06_full_skill_save(self):
        """End-to-end skill generation"""
        self.recorder.on_screen_change("MUSIC/SP ADMIN MENU")
        self.recorder.set_step_name("List_Files")
        self.recorder.on_field_action("PATTERN", "*.*")
        self.recorder.on_aid_key("ENTER")
        
        self.recorder.save()
        
        self.assertTrue(Path("SixMillionTestSkill.ini").exists())
        self.assertTrue(Path("SixMillionTestSkill_recording.html").exists())
        print("✅ 06 - Full Skill Save: PASSED")

    def test_07_partial_save_interrupt(self):
        """Session interrupt / partial save"""
        self.recorder.on_screen_change("ORDER_ENTRY_SCREEN")
        self.recorder.save(partial=True)
        self.assertTrue(Path("SixMillionTestSkill_Partial.ini").exists())
        print("✅ 07 - Partial Save: PASSED")

    def test_08_command_handler(self):
        """Test // command processing"""
        recorder = HitsvilleRecorder("CommandTest")
        result = handle_recorder_command(recorder, "//STEP Enter_Header_Data")
        self.assertTrue(result)
        self.assertEqual(recorder.current_step, "Enter_Header_Data")
        print("✅ 08 - Command Handler: PASSED")

    def test_09_studio_integration(self):
        """Test studio session starter"""
        recorder = start_recording_session("IntegrationTest")
        self.assertIsNotNone(recorder)
        print("✅ 09 - Studio Integration: PASSED")


if __name__ == "__main__":
    print("=" * 90)
    print("🦸 SIX MILLION DOLLAR TEST HARNESS - ACTIVATED")
    print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 90)
    
    unittest.main(verbosity=2, exit=False)
    
    duration = time.time() - unittest.TestResult().startTime if hasattr(unittest, 'TestResult') else "N/A"
    print("\n" + "=" * 90)
    print("🏆 SIX MILLION DOLLAR TEST HARNESS COMPLETE")
    print(f"Duration: {duration:.2f} seconds")
    print("Status: All systems GO - Recorder is ready for production!")
    print("=" * 90)