# hitsville_cli.py - CLI hooks for Hitsville USA Recording Studio

from hitsville_recorder import HitsvilleRecorder

def start_recording_session(skill_name: str, screenshot_mode: bool = False):
    """Main entry point for --learn mode"""
    print(f"🎤 Launching Hitsville USA Recording Studio: {skill_name}")
    print("   You now have a full interactive 3270 terminal.")
    print("   Work naturally. Use // commands for control.\n")
    
    recorder = HitsvilleRecorder(skill_name, screenshot_mode=screenshot_mode)
    return recorder


def handle_recorder_command(recorder: HitsvilleRecorder, command: str) -> bool:
    """Process special // commands typed by the user during recording"""
    if not command.startswith("//"):
        return False
    
    cmd = command.strip().upper()
    
    if cmd.startswith("//STEP "):
        step_name = command[7:].strip()
        recorder.set_step_name(step_name)
        return True
    elif cmd == "//PAUSE":
        recorder.pause()
        return True
    elif cmd == "//RESUME":
        recorder.resume()
        return True
    elif cmd in ("//SAVE", "//SAVE PARTIAL"):
        partial = "PARTIAL" in cmd
        recorder.save(partial=partial)
        return True  # Signal to end recording session
    elif cmd == "//HELP":
        print("Available Hitsville Commands:")
        print("  //STEP <name>     - Name current step")
        print("  //PAUSE            - Pause recording")
        print("  //RESUME           - Resume recording")
        print("  //SAVE             - Finish and save skill")
        print("  //SAVE PARTIAL     - Save interrupted session")
        return True
    
    return False