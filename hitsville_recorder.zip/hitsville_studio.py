# hitsville_studio.py - Full Interactive Recording Studio
import subprocess
import threading
import time
from hitsville_recorder import HitsvilleRecorder

class HitsvilleStudio:
    def __init__(self, skill_name: str, host="tso.tso3270.com", port=26640):
        self.skill_name = skill_name
        self.host = host
        self.port = port
        self.recorder = HitsvilleRecorder(skill_name)

    def print_key_legend(self):
        print("\n" + "="*70)
        print("🎤 HITSVILLE USA - MODERN KEYBOARD MAPPING")
        print("="*70)
        print("Enter          → ENTER")
        print("F1-F12         → PF1 to PF12")
        print("Shift+F1-F12   → PF13 to PF24")
        print("Ctrl+Shift+F1  → PA1")
        print("Ctrl+Shift+F2  → PA2")
        print("Ctrl+Shift+F3  → PA3")
        print("Ctrl+Shift+A   → ATTN")
        print("Esc            → CLEAR")
        print("//STEP Name     → Name current step")
        print("//SAVE           → Finish recording")
        print("="*70 + "\n")

    def launch(self):
        print(f"🎤 Starting Hitsville USA Studio for skill: {self.skill_name}")
        self.print_key_legend()
        
        zti_cmd = ["python", "-m", "tnz.zti", f"{self.host}:{self.port}"]
        try:
            subprocess.run(zti_cmd)
        except FileNotFoundError:
            print("❌ tnz not installed. Run: pip install tnz")