#!/usr/bin/env python3
"""
run_hitsville.py
Simple launcher for SNA-CLAW-3270 Hitsville USA Recording Studio
"""

import sys
import argparse
from hitsville_studio import HitsvilleStudio


def main():
    parser = argparse.ArgumentParser(
        description="🎤 Hitsville USA - SNA-CLAW-3270 Recording Studio",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument("skill_name", 
                       help="Name of the skill to record (e.g. MyOrderEntry)")
    
    parser.add_argument("--host", default="tso.tso3270.com",
                       help="Host to connect to (default: tso.tso3270.com)")
    
    parser.add_argument("--port", type=int, default=26640,
                       help="Port to connect to (default: 26640)")
    
    parser.add_argument("--screenshot", action="store_true",
                       help="Enable screenshot capture during recording")
    
    args = parser.parse_args()

    print("=" * 70)
    print("🎤 HITSVILLE USA RECORDING STUDIO")
    print("=" * 70)
    print(f"Skill Name : {args.skill_name}")
    print(f"Target     : {args.host}:{args.port}")
    print("=" * 70)

    # Launch the full interactive studio
    studio = HitsvilleStudio(
        skill_name=args.skill_name,
        host=args.host,
        port=args.port
    )
    
    studio.launch()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n🎤 Recording session ended by user.")
    except Exception as e:
        print(f"\n❌ Error launching studio: {e}")
        print("Make sure 'tnz' is installed: pip install tnz")