# hitsville_recorder.py - SNA-CLAW-3270 Hitsville USA Session Recorder
import time
import json
from datetime import datetime
from pathlib import Path

class HitsvilleRecorder:
    def __init__(self, skill_name: str, screenshot_mode=False):
        self.skill_name = skill_name
        self.screenshot_mode = screenshot_mode
        self.steps = []
        self.screen_aliases = {}
        self.current_step = "START"
        self.recording_log = []
        self.start_time = datetime.now()
        self.is_paused = False
        self.current_screen = "UNKNOWN"

    def log_action(self, action_type: str, details: dict):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "step": self.current_step,
            "action_type": action_type,
            **details
        }
        self.recording_log.append(entry)
        print(f"[Hitsville 🎤] {action_type}: {details}")

    def on_screen_change(self, screen_data: str):
        if not screen_data or not screen_data.strip():
            return
        signature = hash(screen_data[:800])
        if signature not in self.screen_aliases:
            print(f"\n🎤 === NEW SCREEN DETECTED ===")
            print(f"Preview:\n{screen_data[:400]}...")
            alias = input("   Give this screen a friendly name (e.g. ADMIN_MAIN_MENU): ").strip()
            if not alias:
                alias = f"SCREEN_{len(self.screen_aliases)+1}"
            self.screen_aliases[signature] = alias
            self.log_action("NEW_SCREEN", {"alias": alias})
        self.current_screen = self.screen_aliases[signature]

    def on_field_action(self, field_name: str, value: str):
        self.steps.append({
            "step": self.current_step,
            "screen": self.current_screen,
            "action": f"EnterField({field_name}, '{value}')"
        })
        self.log_action("FIELD_ACTION", {"field": field_name, "value": value})

    def on_aid_key(self, key: str):
        self.steps.append({
            "step": self.current_step,
            "screen": self.current_screen,
            "action": f"Press({key})"
        })
        self.log_action("AID_KEY", {"key": key})

    def set_step_name(self, name: str):
        self.current_step = name
        self.log_action("STEP_RENAME", {"new_step": name})

    def pause(self):
        self.is_paused = True
        print("🎤 Recording PAUSED")

    def resume(self):
        self.is_paused = False
        print("🎤 Recording RESUMED")

    def save(self, partial=False):
        base_name = f"{self.skill_name}{'_Partial' if partial else ''}"
        ini_content = self._build_ini(partial)
        Path(f"{base_name}.ini").write_text(ini_content, encoding='utf-8')
        
        html_content = self._build_html_report()
        Path(f"{base_name}_recording.html").write_text(html_content, encoding='utf-8')
        
        print(f"\n🎤 HITS RECORDED SUCCESSFULLY at Hitsville USA! → {base_name}.ini")

    def _build_ini(self, partial=False):
        lines = [f"; SKILL: {self.skill_name} - Hitsville USA Recording"]
        for step in self.steps:
            lines.append(f"\n[Step:{step.get('step')}]")
            lines.append(f"Screen={step.get('screen')}")
            lines.append(f"Action={step['action']}")
        return "\n".join(lines)

    def _build_html_report(self):
        return f"<h1>Hitsville Recording - {self.skill_name}</h1>"