@echo off
setlocal enabledelayedexpansion

echo.
echo ========================================================
echo    HITSVILLE USA - SNA-CLAW-3270 Recording Studio
echo    "Where the hits are recorded"
echo ========================================================
echo.

:: Check if skill name was provided
if "%~1"=="" (
    echo Usage: run_hitsville.cmd ^<SkillName^>
    echo Example: run_hitsville.cmd MyOrderEntrySkill
    echo.
    pause
    exit /b 1
)

set SKILL_NAME=%~1
set HOST=tso.tso3270.com
set PORT=26640

:: Allow overriding host and port
if not "%~2"=="" set HOST=%~2
if not "%~3"=="" set PORT=%~3

echo Skill Name : %SKILL_NAME%
echo Target Host: %HOST%:%PORT%
echo.
echo Launching full interactive 3270 Recording Studio...
echo Make sure 'tnz' is installed (pip install tnz)
echo.

:: Run the Python launcher
python run_hitsville.py %SKILL_NAME% --host %HOST% --port %PORT%

echo.
echo ========================================================
echo Hitsville USA session ended.
echo ========================================================
echo.

pause