# hitsville_utils.py - Helper functions for Hitsville USA

from datetime import datetime

def suggest_step_name(screen_text: str) -> str:
    """Auto-suggest logical step name based on screen content"""
    if not screen_text:
        return "UNKNOWN_STEP"
    
    text = screen_text.upper()[:300]
    
    if any(x in text for x in ["MENU", "OPTION", "SELECT"]):
        return "MAIN_MENU"
    elif any(x in text for x in ["SIGNON", "LOGIN", "USERID"]):
        return "SIGN_ON"
    elif "PASSWORD" in text:
        return "ENTER_PASSWORD"
    elif any(x in text for x in ["ERROR", "FAILED", "ABEND"]):
        return "ERROR_HANDLING"
    elif "CONFIRM" in text or "SUCCESS" in text:
        return "CONFIRMATION"
    elif "LIST" in text or "DISPLAY" in text:
        return "LIST_FILES"
    
    return f"STEP_{datetime.now().strftime('%H%M%S')}"


def print_screen_preview(screen_data: str, max_lines: int = 12):
    """Print clean preview of current screen"""
    lines = [line.rstrip() for line in screen_data.split('\n')[:max_lines]]
    print("\n" + "-" * 60)
    print("CURRENT SCREEN PREVIEW:")
    print("\n".join(lines))
    if len(lines) < max_lines:
        print(" " * 20 + "... (screen continues) ...")
    print("-" * 60)